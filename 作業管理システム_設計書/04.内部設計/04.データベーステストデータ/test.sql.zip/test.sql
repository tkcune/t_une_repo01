-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- ホスト: 127.0.0.1
-- 生成日時: 2021-09-06 04:00:40
-- サーバのバージョン： 10.4.19-MariaDB
-- PHP のバージョン: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `test`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `dcbs01`
--

CREATE TABLE `dcbs01` (
  `client_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsible_person_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `management_personnel_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_start_date` datetime DEFAULT NULL,
  `operation_end_date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `dcbs01`
--

INSERT INTO `dcbs01` (`client_id`, `department_id`, `responsible_person_id`, `name`, `status`, `management_personnel_id`, `operation_start_date`, `operation_end_date`, `created_at`, `updated_at`) VALUES
('aa00000001', 'bs00000001', 'ji00000001', '部署A', '10', 'ji00000001', NULL, NULL, '2021-09-06 01:20:38', '2021-09-06 01:20:38'),
('aa00000001', 'bs00000002', 'ji00000001', '部署B', '12', 'ji00000001', NULL, NULL, '2021-09-06 01:20:53', '2021-09-06 01:20:53'),
('aa00000001', 'bs00000003', 'ji00000001', '部署C', '13', 'ji00000001', '2021-09-06 10:21:02', NULL, '2021-09-06 01:21:02', '2021-09-06 01:21:02'),
('aa00000001', 'bs00000004', 'ji00000001', '部署D', '14', 'ji00000001', NULL, NULL, '2021-09-06 01:21:12', '2021-09-06 01:21:12'),
('aa00000001', 'bs00000005', 'ji00000001', '部署E', '18', 'ji00000001', NULL, '2021-09-06 10:21:21', '2021-09-06 01:21:21', '2021-09-06 01:21:21'),
('aa00000001', 'bs00000006', 'ji00000001', '部署F', '11', 'ji00000001', NULL, NULL, '2021-09-06 01:21:33', '2021-09-06 01:21:33'),
('aa00000001', 'bs00000007', 'ji00000001', '部署G', '13', 'ji00000001', '2021-09-06 10:28:10', NULL, '2021-09-06 01:28:10', '2021-09-06 01:28:10'),
('aa00000001', 'bs00000008', 'ji00000001', '部署H', '13', 'ji00000001', '2021-09-06 10:28:19', NULL, '2021-09-06 01:28:19', '2021-09-06 01:28:19'),
('aa00000001', 'bs00000009', 'ji00000001', '部署I', '14', 'ji00000001', NULL, NULL, '2021-09-06 01:28:26', '2021-09-06 01:28:26');

-- --------------------------------------------------------

--
-- テーブルの構造 `dccmks`
--

CREATE TABLE `dccmks` (
  `client_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lower_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `high_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `dccmks`
--

INSERT INTO `dccmks` (`client_id`, `lower_id`, `high_id`, `created_at`, `updated_at`) VALUES
('aa00000001', 'bs00000002', 'bs00000001', NULL, NULL),
('aa00000001', 'bs00000003', 'bs00000001', NULL, NULL),
('aa00000001', 'bs00000004', 'bs00000002', NULL, NULL),
('aa00000001', 'bs00000005', 'bs00000002', NULL, NULL),
('aa00000001', 'bs00000006', 'bs00000003', NULL, NULL),
('aa00000001', 'bs00000007', 'bs00000003', NULL, NULL),
('aa00000001', 'bs00000008', 'bs00000004', NULL, NULL),
('aa00000001', 'bs00000009', 'bs00000006', NULL, NULL),
('aa00000001', 'ji00000001', 'bs00000001', NULL, NULL),
('aa00000001', 'ji00000002', 'bs00000002', NULL, NULL),
('aa00000001', 'ji00000003', 'bs00000002', NULL, NULL),
('aa00000001', 'ji00000004', 'bs00000002', NULL, NULL),
('aa00000001', 'ji00000005', 'bs00000002', NULL, NULL),
('aa00000001', 'ji00000006', 'bs00000002', NULL, NULL),
('aa00000001', 'ji00000007', 'bs00000002', NULL, NULL),
('aa00000001', 'ji00000008', 'bs00000004', NULL, NULL),
('aa00000001', 'ji00000009', 'bs00000004', NULL, NULL),
('aa00000001', 'ji00000010', 'bs00000004', NULL, NULL),
('aa00000001', 'ta00000001', 'bs00000003', NULL, NULL),
('aa00000001', 'ta00000002', 'bs00000007', NULL, NULL),
('aa00000001', 'ta00000003', 'bs00000003', NULL, NULL),
('aa00000001', 'ta00000004', 'bs00000008', NULL, NULL),
('aa00000001', 'ta00000005', 'bs00000003', NULL, NULL);

-- --------------------------------------------------------

--
-- テーブルの構造 `dccmta`
--

CREATE TABLE `dccmta` (
  `client_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `projection_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `projection_source_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `dccmta`
--

INSERT INTO `dccmta` (`client_id`, `projection_id`, `projection_source_id`, `created_at`, `updated_at`) VALUES
('aa00000001', 'ta00000001', 'bs00000002', NULL, NULL),
('aa00000001', 'ta00000002', 'bs00000004', NULL, NULL),
('aa00000001', 'ta00000003', 'bs00000004', NULL, NULL),
('aa00000001', 'ta00000004', 'bs00000006', NULL, NULL),
('aa00000001', 'ta00000005', 'bs00000006', NULL, NULL);

-- --------------------------------------------------------

--
-- テーブルの構造 `dcji01`
--

CREATE TABLE `dcji01` (
  `client_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `personnel_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_update_day` datetime NOT NULL,
  `status` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `management_personnel_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_authority` tinyint(1) NOT NULL,
  `system_management` tinyint(1) NOT NULL,
  `operation_start_date` datetime DEFAULT NULL,
  `operation_end_date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `dcji01`
--

INSERT INTO `dcji01` (`client_id`, `personnel_id`, `name`, `email`, `password`, `password_update_day`, `status`, `management_personnel_id`, `login_authority`, `system_management`, `operation_start_date`, `operation_end_date`, `created_at`, `updated_at`) VALUES
('aa00000001', 'ji00000001', '山田一郎', 'yamada@itirou.com', '$2y$10$itulf4IwKeCWlfyuAl7IhetjEUV/xTG/MoNJ4d6M1eAckr8dC2dA.', '2021-09-06 10:22:19', '10', 'ji00000001', 1, 1, NULL, NULL, '2021-09-06 01:22:19', '2021-09-06 01:22:19'),
('aa00000001', 'ji00000002', '田中次郎', 'tanaka@zirou.com', '$2y$10$.jmhtjQiOD5I00Fxe1.uDeAQC9nHS0sZ8Ixjy4pzJvk3yS2Bnwf4K', '2021-09-06 10:22:57', '11', 'ji00000002', 1, 1, NULL, NULL, '2021-09-06 01:22:57', '2021-09-06 01:22:57'),
('aa00000001', 'ji00000003', '佐藤三郎', 'satou@saburou.com', '$2y$10$0545288pe8P/P/kgy2mZM.8QfnR0Gn.SApnIfRJhefzwa8QGX79/2', '2021-09-06 10:24:22', '13', 'ji00000003', 0, 0, '2021-09-06 10:24:22', NULL, '2021-09-06 01:24:22', '2021-09-06 01:24:22'),
('aa00000001', 'ji00000004', '佐々木花子', 'sasaki@hanako.com', '$2y$10$TZ/smM.VJdhY6d9XzYnHTOBNtC4sPUndl/znyH9N97vBXHUPwX42S', '2021-09-06 10:25:37', '18', 'ji00000004', 0, 0, NULL, '2021-09-06 10:25:37', '2021-09-06 01:25:37', '2021-09-06 01:25:37'),
('aa00000001', 'ji00000005', '佐々木京子', 'sasaki@kyouko.com', '$2y$10$6cZOWiFb6h.1P/.akvikMeG6QoPXvO0DZQrXqFovA5ScdkUV1ppGm', '2021-09-06 10:26:08', '14', 'ji00000005', 1, 1, NULL, NULL, '2021-09-06 01:26:08', '2021-09-06 01:26:08'),
('aa00000001', 'ji00000006', '上田四郎', 'ueda@sirou.com', '$2y$10$MgSpP5wuWKwSpdMlcfr4GuhZ0hJ.C4ZkKn/d8IdnjzYVdFDeofLKy', '2021-09-06 10:27:49', '11', 'ji00000006', 0, 0, NULL, NULL, '2021-09-06 01:27:49', '2021-09-06 01:27:49'),
('aa00000001', 'ji00000007', '下山五郎', 'simoyama@gorou.com', '$2y$10$Sr9RRVQD1VVGs6Robx1yjOqlBIpaLc1bPWas4t7e/s8OZNyBG65nS', '2021-09-06 10:29:36', '13', 'ji00000007', 1, 1, '2021-09-06 10:29:36', NULL, '2021-09-06 01:29:36', '2021-09-06 01:29:36'),
('aa00000001', 'ji00000008', '浅田桜子', 'asada@sakurako.com', '$2y$10$45cLPp9J9quT1puKyLd5p.6RDMoBaV9NA1/yFhe29LWOomhnJyco6', '2021-09-06 10:30:12', '14', 'ji00000008', 1, 0, NULL, NULL, '2021-09-06 01:30:12', '2021-09-06 01:30:12'),
('aa00000001', 'ji00000009', '山田恭子', 'yamada@kyouko.com', '$2y$10$I5YGcb564hVxuxtgCfU8X.e8vlqLDm17eR4NXorktbyAp5y2yYNJG', '2021-09-06 10:31:34', '13', 'ji00000009', 1, 1, '2021-09-06 10:31:34', NULL, '2021-09-06 01:31:34', '2021-09-06 01:31:34'),
('aa00000001', 'ji00000010', '高橋花子', 'takahasi@hanako.com', '$2y$10$AjVYz1C75May3.ykuUBI5OuJueL2dl967AYLlIG4biOZt5K1hoLQW', '2021-09-06 10:32:25', '12', 'ji00000010', 0, 0, NULL, NULL, '2021-09-06 01:32:25', '2021-09-06 01:32:25');

-- --------------------------------------------------------

--
-- テーブルの構造 `dclg01`
--

CREATE TABLE `dclg01` (
  `client_id` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `log_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `type` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `function` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `program_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `log` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- テーブルのデータのダンプ `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_08_05_100738_create_dcji01_table', 1),
(5, '2021_08_05_102153_create_dcbs01_table', 1),
(6, '2021_08_05_102208_create_dccm01_table', 1),
(7, '2021_08_05_102220_create_dcta01_table', 1),
(9, '2021_08_05_102232_create_dclg01_table', 2);

-- --------------------------------------------------------

--
-- テーブルの構造 `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `dcbs01`
--
ALTER TABLE `dcbs01`
  ADD PRIMARY KEY (`client_id`,`department_id`);

--
-- テーブルのインデックス `dccmks`
--
ALTER TABLE `dccmks`
  ADD PRIMARY KEY (`client_id`,`lower_id`,`high_id`);

--
-- テーブルのインデックス `dccmta`
--
ALTER TABLE `dccmta`
  ADD PRIMARY KEY (`client_id`,`projection_id`);

--
-- テーブルのインデックス `dcji01`
--
ALTER TABLE `dcji01`
  ADD PRIMARY KEY (`client_id`,`personnel_id`);

--
-- テーブルのインデックス `dclg01`
--
ALTER TABLE `dclg01`
  ADD PRIMARY KEY (`client_id`,`log_id`);

--
-- テーブルのインデックス `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- テーブルのインデックス `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- テーブルのインデックス `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- ダンプしたテーブルの AUTO_INCREMENT
--

--
-- テーブルの AUTO_INCREMENT `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- テーブルの AUTO_INCREMENT `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- テーブルの AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
